package com.qarevise.app;
import android.app.*; import android.content.*; import java.util.Calendar;

public class Rec extends BroadcastReceiver {
    static PendingIntent pi(Context c) { return PendingIntent.getBroadcast(c, 1, new Intent(c, Rec.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); }
    static void schedule(Context c) {
        SharedPreferences p = c.getSharedPreferences("p", 0);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (!p.getBoolean("on", false)) { am.cancel(pi(c)); return; }
        Calendar k = Calendar.getInstance();
        k.set(Calendar.HOUR_OF_DAY, p.getInt("h", 20)); k.set(Calendar.MINUTE, p.getInt("m", 0)); k.set(Calendar.SECOND, 0);
        if (k.getTimeInMillis() <= System.currentTimeMillis()) k.add(Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, k.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi(c));
    }
    @Override public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) { schedule(c); return; }
        SharedPreferences p = c.getSharedPreferences("p", 0);
        if (!p.getBoolean("on", false)) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("r", "Revision reminder", NotificationManager.IMPORTANCE_DEFAULT));
        int n = p.getInt("due", 0);
        PendingIntent open = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(c, "r").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Revision time!").setContentText(n > 0 ? "Aaj " + n + " Q&A revise karne hain" : "Aaj ka revision check karo")
            .setContentIntent(open).setAutoCancel(true);
        nm.notify(1, b.build());
    }
}
