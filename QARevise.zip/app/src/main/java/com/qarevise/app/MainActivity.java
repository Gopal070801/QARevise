package com.qarevise.app;
import android.app.Activity; import android.app.AlertDialog; import android.content.SharedPreferences;
import android.os.Bundle; import android.print.PrintAttributes; import android.print.PrintManager;
import android.webkit.*; import android.widget.EditText;

public class MainActivity extends Activity {
    WebView w;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        setContentView(w);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        w.addJavascriptInterface(new Br(), "Android");
        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setPositiveButton("OK", (d, i) -> r.confirm()).setOnCancelListener(d -> r.confirm()).show(); return true; }
            @Override public boolean onJsConfirm(WebView v, String u, String m, JsResult r) {
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setPositiveButton("OK", (d, i) -> r.confirm()).setNegativeButton("Cancel", (d, i) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show(); return true; }
            @Override public boolean onJsPrompt(WebView v, String u, String m, String def, JsPromptResult r) {
                EditText e = new EditText(MainActivity.this); e.setText(def);
                new AlertDialog.Builder(MainActivity.this).setMessage(m).setView(e).setPositiveButton("OK", (d, i) -> r.confirm(e.getText().toString())).setNegativeButton("Cancel", (d, i) -> r.cancel()).setOnCancelListener(d -> r.cancel()).show(); return true; }
        });
        w.loadUrl("file:///android_asset/index.html");
    }
    class Br {
        @JavascriptInterface public void print() {
            runOnUiThread(() -> ((PrintManager) getSystemService(PRINT_SERVICE)).print("QA Revise", w.createPrintDocumentAdapter("QA_Revise"), new PrintAttributes.Builder().build()));
        }
        @JavascriptInterface public void setDue(int n) { getSharedPreferences("p", 0).edit().putInt("due", n).apply(); }
        @JavascriptInterface public void setReminder(boolean on, int h, int m) {
            getSharedPreferences("p", 0).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply();
            Rec.schedule(MainActivity.this);
        }
    }
    @Override public void onBackPressed() { finish(); }
}
